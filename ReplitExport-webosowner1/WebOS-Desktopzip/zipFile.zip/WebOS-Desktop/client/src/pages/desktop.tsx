import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  AppWindow,
  BookOpen,
  Cog,
  FileText,
  Folder,
  Globe,
  Info,
  LayoutGrid,
  Maximize2,
  Minus,
  Moon,
  Sun,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch as UISwitch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import aurora from "@/assets/images/wallpaper-aurora.png";
import sky from "@/assets/images/wallpaper-sky.png";
import graphite from "@/assets/images/wallpaper-graphite.png";

const LS_KEYS = {
  firstRun: "webos.firstRunDismissed.v1",
  notes: "webos.notes.v1",
  theme: "webos.theme.v1",
  accent: "webos.accent.v1",
  wallpaper: "webos.wallpaper.v1",
};

type AppId = "notes" | "files" | "browser" | "settings" | "about";

type WindowState = {
  id: string;
  appId: AppId;
  title: string;
  minimized: boolean;
  maximized: boolean;
  x: number;
  y: number;
  w: number;
  h: number;
  z: number;
};

type WallpaperId = "aurora" | "sky" | "graphite";

type SettingsState = {
  darkMode: boolean;
  accent: string;
  wallpaper: WallpaperId;
};

const WALLPAPERS: Record<WallpaperId, { name: string; src: string }>= {
  aurora: { name: "Aurora", src: aurora },
  sky: { name: "Sky", src: sky },
  graphite: { name: "Graphite", src: graphite },
};

const ACCENTS = [
  { name: "Blue", value: "206 92% 60%" },
  { name: "Violet", value: "265 92% 64%" },
  { name: "Mint", value: "165 78% 44%" },
  { name: "Amber", value: "36 92% 55%" },
  { name: "Rose", value: "350 88% 62%" },
];

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

function useLocalStorageState<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) return initial;
      return JSON.parse(raw) as T;
    } catch {
      return initial;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      // ignore
    }
  }, [key, value]);

  return [value, setValue] as const;
}

function formatClock(d: Date) {
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function formatDate(d: Date) {
  return d.toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" });
}

function appMeta(appId: AppId) {
  switch (appId) {
    case "notes":
      return { title: "Notes", icon: FileText };
    case "files":
      return { title: "Files", icon: Folder };
    case "browser":
      return { title: "Browser", icon: Globe };
    case "settings":
      return { title: "Settings", icon: Cog };
    case "about":
      return { title: "About", icon: Info };
  }
}

function randomId() {
  return Math.random().toString(36).slice(2, 9);
}

function defaultWindowFor(appId: AppId, index: number, isMobile: boolean): Omit<WindowState, "z"> {
  const meta = appMeta(appId);
  const baseW = isMobile ? 0.94 : 0.56;
  const baseH = isMobile ? 0.78 : 0.6;

  return {
    id: `${appId}-${Date.now()}-${randomId()}`,
    appId,
    title: meta.title,
    minimized: false,
    maximized: isMobile,
    x: isMobile ? 12 : 110 + index * 24,
    y: isMobile ? 18 : 90 + index * 20,
    w: isMobile ? Math.floor(window.innerWidth * baseW) : Math.floor(window.innerWidth * baseW),
    h: isMobile ? Math.floor(window.innerHeight * baseH) : Math.floor(window.innerHeight * baseH),
  };
}

function isSmallScreen() {
  return typeof window !== "undefined" && window.matchMedia("(max-width: 768px)").matches;
}

function DesktopIcon({
  label,
  Icon,
  onOpen,
  testId,
}: {
  label: string;
  Icon: any;
  onOpen: () => void;
  testId: string;
}) {
  return (
    <button
      type="button"
      onDoubleClick={onOpen}
      onClick={() => {
        // single click selects in a real desktop; keep it simple
      }}
      className="group flex w-[92px] flex-col items-center gap-2 rounded-xl px-2 py-3 text-left text-white/90 hover:bg-white/10 active:bg-white/14 transition ease-out-smooth"
      data-testid={testId}
    >
      <span className="grid h-12 w-12 place-items-center rounded-2xl bg-white/12 ring-1 ring-white/15 shadow-[0_10px_30px_rgba(0,0,0,.22)] group-hover:bg-white/16 transition ease-out-smooth">
        <Icon className="h-6 w-6" strokeWidth={1.8} />
      </span>
      <span className="text-center text-[12px] leading-tight drop-shadow-[0_2px_10px_rgba(0,0,0,.45)]">
        {label}
      </span>
    </button>
  );
}

function WindowChrome({
  title,
  icon: Icon,
  active,
  maximized,
  onMinimize,
  onMaximize,
  onClose,
  dragHandleProps,
}: {
  title: string;
  icon: any;
  active: boolean;
  maximized: boolean;
  onMinimize: () => void;
  onMaximize: () => void;
  onClose: () => void;
  dragHandleProps?: any;
}) {
  return (
    <div
      className={cn(
        "flex items-center justify-between gap-2 rounded-t-[16px] px-3 py-2",
        "bg-black/20 dark:bg-black/30",
        active ? "ring-1 ring-white/20" : "ring-1 ring-white/12",
      )}
      {...dragHandleProps}
    >
      <div className="flex min-w-0 items-center gap-2">
        <span className={cn("grid h-8 w-8 place-items-center rounded-xl", active ? "bg-white/14" : "bg-white/10")}>
          <Icon className="h-4.5 w-4.5" strokeWidth={2} />
        </span>
        <div className="min-w-0">
          <div className="truncate text-[13px] font-medium text-white/90" data-testid="text-window-title">
            {title}
          </div>
        </div>
      </div>

      <div className="flex items-center gap-1">
        <button
          type="button"
          className="grid h-9 w-9 place-items-center rounded-xl text-white/85 hover:bg-white/12 active:bg-white/16 transition"
          onClick={onMinimize}
          data-testid="button-window-minimize"
          aria-label="Minimize"
        >
          <Minus className="h-4 w-4" />
        </button>
        <button
          type="button"
          className="grid h-9 w-9 place-items-center rounded-xl text-white/85 hover:bg-white/12 active:bg-white/16 transition"
          onClick={onMaximize}
          data-testid="button-window-maximize"
          aria-label={maximized ? "Restore" : "Maximize"}
        >
          <Maximize2 className="h-4 w-4" />
        </button>
        <button
          type="button"
          className="grid h-9 w-9 place-items-center rounded-xl text-white/85 hover:bg-red-500/40 active:bg-red-500/55 transition"
          onClick={onClose}
          data-testid="button-window-close"
          aria-label="Close"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}

function ResizerHandle({ onPointerDown, testId }: { onPointerDown: (e: any) => void; testId: string }) {
  return (
    <div
      onPointerDown={onPointerDown}
      className="absolute bottom-0 right-0 h-5 w-5 cursor-nwse-resize"
      data-testid={testId}
    >
      <div className="absolute bottom-1.5 right-1.5 h-3 w-3 rounded-sm bg-white/18 ring-1 ring-white/25" />
    </div>
  );
}

function FirstRunOverlay({ onDismiss }: { onDismiss: () => void }) {
  return (
    <div className="absolute inset-0 z-[9999] grid place-items-center p-4">
      <div className="absolute inset-0 bg-black/55 backdrop-blur-md" />
      <motion.div
        initial={{ opacity: 0, y: 14, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        className="relative w-full max-w-xl rounded-2xl glass p-6 text-foreground"
        data-testid="modal-first-run"
      >
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-[var(--desktop-accent)] text-white shadow-[0_18px_40px_rgba(0,0,0,.25)]">
              <LayoutGrid className="h-5 w-5" />
            </span>
            <div>
              <div className="text-sm font-semibold tracking-tight">Welcome to WebOS Desktop</div>
              <div className="text-xs text-muted-foreground">A desktop-style web simulation</div>
            </div>
          </div>
        </div>

        <div className="mt-4 space-y-3 text-sm">
          <p data-testid="text-first-run-disclaimer">
            This is a <span className="font-medium">web simulation</span> inspired by modern desktop interfaces. It is not
            affiliated with Microsoft and does not use Microsoft trademarks or assets.
          </p>
          <div className="rounded-xl border bg-white/50 dark:bg-white/5 p-3">
            <div className="flex items-start gap-3">
              <span className="mt-0.5 grid h-8 w-8 place-items-center rounded-xl bg-white/70 dark:bg-white/10">
                <BookOpen className="h-4 w-4" />
              </span>
              <div className="space-y-1">
                <div className="text-sm font-medium">Quick tips</div>
                <ul className="list-disc pl-5 text-xs text-muted-foreground space-y-1">
                  <li>Double-click desktop icons to open apps.</li>
                  <li>Use the taskbar buttons to switch and minimize windows.</li>
                  <li>On mobile, windows open full-screen for easier use.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-5 flex flex-col sm:flex-row gap-2 sm:items-center sm:justify-end">
          <Button
            variant="secondary"
            className="rounded-xl"
            onClick={() => {
              try {
                localStorage.removeItem(LS_KEYS.firstRun);
              } catch {
                // ignore
              }
              onDismiss();
            }}
            data-testid="button-first-run-continue"
          >
            Enter Desktop
          </Button>
        </div>
      </motion.div>
    </div>
  );
}

function StartMenu({
  open,
  onOpenApp,
  onClose,
  clock,
  date,
  isMobile,
}: {
  open: boolean;
  onOpenApp: (id: AppId) => void;
  onClose: () => void;
  clock: string;
  date: string;
  isMobile: boolean;
}) {
  if (!open) return null;
  return (
    <div className="absolute inset-0 z-[8000]" onMouseDown={onClose} data-testid="overlay-start-menu">
      <div className="absolute inset-0" />
      <motion.div
        initial={{ opacity: 0, y: 12, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        className={cn(
          "absolute left-3 bottom-[72px] w-[340px] rounded-2xl glass p-3",
          isMobile && "left-3 right-3 w-auto bottom-[78px]",
        )}
        onMouseDown={(e) => e.stopPropagation()}
        data-testid="panel-start-menu"
      >
        <div className="flex items-center justify-between">
          <div>
            <div className="text-[12px] font-semibold tracking-tight">Start</div>
            <div className="text-[11px] text-muted-foreground">Open an app</div>
          </div>
          <div className="text-right">
            <div className="text-[12px] font-medium" data-testid="text-start-clock">
              {clock}
            </div>
            <div className="text-[11px] text-muted-foreground" data-testid="text-start-date">
              {date}
            </div>
          </div>
        </div>

        <div className="mt-3 grid grid-cols-2 gap-2">
          {([
            ["notes", FileText],
            ["files", Folder],
            ["browser", Globe],
            ["settings", Cog],
          ] as Array<[AppId, any]>).map(([id, Icon]) => {
            const meta = appMeta(id);
            return (
              <button
                key={id}
                className="group flex items-center gap-3 rounded-xl border bg-white/55 dark:bg-white/5 px-3 py-2 text-left hover:bg-white/65 dark:hover:bg-white/8 transition"
                onClick={() => {
                  onOpenApp(id);
                  onClose();
                }}
                data-testid={`button-start-open-${id}`}
              >
                <span className="grid h-9 w-9 place-items-center rounded-xl bg-[var(--desktop-accent)] text-white shadow-[0_16px_36px_rgba(0,0,0,.22)]">
                  <Icon className="h-4.5 w-4.5" strokeWidth={2} />
                </span>
                <div className="min-w-0">
                  <div className="truncate text-[13px] font-medium">{meta.title}</div>
                  <div className="truncate text-[11px] text-muted-foreground">Open {meta.title}</div>
                </div>
              </button>
            );
          })}
        </div>

        <div className="mt-3 rounded-xl border bg-white/50 dark:bg-white/5 p-3">
          <div className="flex items-start gap-3">
            <span className="mt-0.5 grid h-8 w-8 place-items-center rounded-xl bg-white/70 dark:bg-white/10">
              <AppWindow className="h-4 w-4" />
            </span>
            <div className="space-y-1">
              <div className="text-sm font-medium">Deployment</div>
              <p className="text-xs text-muted-foreground" data-testid="text-deploy-guidance">
                When you’re ready to share, you can publish on Replit and get a free hosted link like
                <span className="font-medium"> your-app.replit.app</span> — no domain purchase needed.
              </p>
              <p className="text-xs text-muted-foreground">
                Later, if you buy a custom domain, you can connect it in Deployment settings by adding the DNS records Replit
                provides.
              </p>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

function NotesApp({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <div className="h-full p-3">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-sm font-semibold">Notes</div>
          <div className="text-xs text-muted-foreground" data-testid="text-notes-hint">
            Autosaved to your browser
          </div>
        </div>
      </div>

      <div className="mt-3 h-[calc(100%-52px)]">
        <Textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="h-full resize-none rounded-2xl border bg-white/60 dark:bg-white/5 font-mono text-[13px] leading-relaxed shadow-sm"
          placeholder="Write something…"
          data-testid="input-notes"
        />
      </div>
    </div>
  );
}

type FakeNode =
  | { type: "folder"; name: string; children: FakeNode[] }
  | { type: "file"; name: string; size: string };

const FAKE_FS: FakeNode = {
  type: "folder",
  name: "Home",
  children: [
    {
      type: "folder",
      name: "Projects",
      children: [
        { type: "file", name: "webos-desktop.txt", size: "2 KB" },
        { type: "file", name: "notes.md", size: "5 KB" },
        { type: "file", name: "ideas.todo", size: "1 KB" },
      ],
    },
    {
      type: "folder",
      name: "Pictures",
      children: [
        { type: "file", name: "aurora.png", size: "1.4 MB" },
        { type: "file", name: "sky.png", size: "900 KB" },
      ],
    },
    {
      type: "folder",
      name: "Downloads",
      children: [
        { type: "file", name: "readme.pdf", size: "240 KB" },
        { type: "file", name: "setup.zip", size: "12 MB" },
      ],
    },
  ],
};

function FilesApp() {
  const [path, setPath] = useState<string[]>([FAKE_FS.name]);
  const [node, setNode] = useState<FakeNode>(FAKE_FS);

  function openFolder(name: string) {
    if (node.type !== "folder") return;
    const child = node.children.find((c) => c.type === "folder" && c.name === name);
    if (!child || child.type !== "folder") return;
    setNode(child);
    setPath((p) => [...p, name]);
  }

  function goUp() {
    const nextPath = path.slice(0, -1);
    if (nextPath.length === 0) return;

    let cur: FakeNode = FAKE_FS;
    for (let i = 1; i < nextPath.length; i++) {
      const name = nextPath[i];
      if (cur.type !== "folder") break;
      const next = cur.children.find((c) => c.type === "folder" && c.name === name);
      if (!next || next.type !== "folder") break;
      cur = next;
    }

    setPath(nextPath);
    setNode(cur);
  }

  const items = node.type === "folder" ? node.children : [];

  return (
    <div className="h-full p-3">
      <div className="flex items-center justify-between gap-2">
        <div className="min-w-0">
          <div className="text-sm font-semibold">Files</div>
          <div className="truncate text-xs text-muted-foreground" data-testid="text-files-path">
            /{path.slice(1).join("/")}
          </div>
        </div>
        <Button
          variant="secondary"
          size="sm"
          onClick={goUp}
          className="rounded-xl"
          data-testid="button-files-up"
        >
          Up
        </Button>
      </div>

      <div className="mt-3 rounded-2xl border bg-white/55 dark:bg-white/5 overflow-hidden">
        <div className="grid grid-cols-[1fr_auto] gap-2 px-3 py-2 text-[12px] font-medium border-b bg-white/40 dark:bg-white/5">
          <div>Name</div>
          <div>Size</div>
        </div>
        <div className="max-h-[calc(100%-72px)] overflow-auto">
          {items.map((it, idx) => {
            const isFolder = it.type === "folder";
            return (
              <button
                key={idx}
                className="w-full grid grid-cols-[1fr_auto] items-center gap-2 px-3 py-2 text-left text-[13px] hover:bg-white/45 dark:hover:bg-white/6 transition"
                onClick={() => {
                  if (isFolder) openFolder(it.name);
                }}
                data-testid={`row-files-${idx}`}
              >
                <div className="flex items-center gap-2 min-w-0">
                  <span className={cn("grid h-8 w-8 place-items-center rounded-xl", isFolder ? "bg-[var(--desktop-accent)] text-white" : "bg-white/70 dark:bg-white/10")}>
                    {isFolder ? <Folder className="h-4 w-4" /> : <FileText className="h-4 w-4" />}
                  </span>
                  <div className="truncate" data-testid={`text-files-name-${idx}`}>
                    {it.name}
                  </div>
                </div>
                <div className="text-xs text-muted-foreground" data-testid={`text-files-size-${idx}`}>
                  {it.type === "file" ? it.size : "—"}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      <div className="mt-3 text-xs text-muted-foreground" data-testid="text-files-footnote">
        This is a fake file list for the demo.
      </div>
    </div>
  );
}

const ALLOWED_SITES = [
  { label: "Example", value: "https://example.com" },
  { label: "MDN", value: "https://developer.mozilla.org" },
  { label: "Wikipedia", value: "https://wikipedia.org" },
];

function BrowserApp() {
  const [url, setUrl] = useState(ALLOWED_SITES[0]!.value);
  const [activeUrl, setActiveUrl] = useState(ALLOWED_SITES[0]!.value);
  const allowedSet = useMemo(() => new Set(ALLOWED_SITES.map((s) => s.value)), []);

  const isAllowed = allowedSet.has(activeUrl);

  return (
    <div className="h-full">
      <div className="p-3 pb-2">
        <div className="flex items-center gap-2">
          <Input
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            className="rounded-xl bg-white/60 dark:bg-white/5"
            placeholder="Enter a URL (limited)"
            data-testid="input-browser-url"
          />
          <Button
            onClick={() => setActiveUrl(url)}
            className="rounded-xl"
            data-testid="button-browser-go"
          >
            Go
          </Button>
        </div>
        <div className="mt-2 flex flex-wrap gap-2">
          {ALLOWED_SITES.map((s) => (
            <button
              key={s.value}
              className={cn(
                "rounded-full border px-3 py-1 text-[12px] transition",
                activeUrl === s.value
                  ? "bg-[var(--desktop-accent)] text-white border-transparent"
                  : "bg-white/55 dark:bg-white/5 hover:bg-white/65 dark:hover:bg-white/8",
              )}
              onClick={() => {
                setUrl(s.value);
                setActiveUrl(s.value);
              }}
              data-testid={`button-browser-preset-${s.label.toLowerCase()}`}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      <div className="h-[calc(100%-92px)] border-t bg-white/30 dark:bg-black/20">
        {isAllowed ? (
          <iframe
            key={activeUrl}
            src={activeUrl}
            className="h-full w-full"
            sandbox="allow-forms allow-scripts allow-same-origin allow-popups"
            referrerPolicy="no-referrer"
            data-testid="iframe-browser"
            title="WebOS Browser"
          />
        ) : (
          <div className="h-full grid place-items-center p-6">
            <div className="max-w-md rounded-2xl border bg-white/60 dark:bg-white/5 p-4">
              <div className="text-sm font-semibold" data-testid="text-browser-blocked-title">
                This site is blocked in the demo
              </div>
              <div className="mt-1 text-xs text-muted-foreground" data-testid="text-browser-blocked-desc">
                For safety, the browser window only allows a small list of sites. Pick a preset above.
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function SettingsApp({
  settings,
  onSettings,
  onOpenAbout,
}: {
  settings: SettingsState;
  onSettings: (next: SettingsState) => void;
  onOpenAbout: () => void;
}) {
  return (
    <div className="h-full p-3">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-sm font-semibold">Settings</div>
          <div className="text-xs text-muted-foreground" data-testid="text-settings-hint">
            Personalize your desktop
          </div>
        </div>
        <Button
          variant="secondary"
          size="sm"
          onClick={onOpenAbout}
          className="rounded-xl"
          data-testid="button-open-about"
        >
          About
        </Button>
      </div>

      <div className="mt-3 grid gap-3">
        <div className="rounded-2xl border bg-white/55 dark:bg-white/5 p-4">
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <div className="text-sm font-medium">Dark mode</div>
              <div className="text-xs text-muted-foreground">Toggles the UI theme</div>
            </div>
            <div className="flex items-center gap-2">
              <Sun className="h-4 w-4 text-muted-foreground" />
              <UISwitch
                checked={settings.darkMode}
                onCheckedChange={(v) => onSettings({ ...settings, darkMode: v })}
                data-testid="toggle-dark-mode"
              />
              <Moon className="h-4 w-4 text-muted-foreground" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl border bg-white/55 dark:bg-white/5 p-4">
          <div className="text-sm font-medium">Accent color</div>
          <div className="mt-2 grid grid-cols-2 sm:grid-cols-5 gap-2">
            {ACCENTS.map((a) => {
              const selected = settings.accent === a.value;
              return (
                <button
                  key={a.value}
                  className={cn(
                    "flex items-center justify-between gap-2 rounded-xl border px-3 py-2 text-left text-[12px] transition",
                    selected
                      ? "border-transparent bg-[var(--desktop-accent)] text-white"
                      : "bg-white/55 dark:bg-white/5 hover:bg-white/65 dark:hover:bg-white/8",
                  )}
                  onClick={() => onSettings({ ...settings, accent: a.value })}
                  data-testid={`button-accent-${a.name.toLowerCase()}`}
                >
                  <span className="font-medium">{a.name}</span>
                  <span
                    className="h-4 w-4 rounded-full ring-1 ring-black/10"
                    style={{ background: `hsl(${a.value})` }}
                  />
                </button>
              );
            })}
          </div>
        </div>

        <div className="rounded-2xl border bg-white/55 dark:bg-white/5 p-4">
          <div className="text-sm font-medium">Wallpaper</div>
          <div className="mt-2 grid grid-cols-1 sm:grid-cols-3 gap-2">
            {(Object.keys(WALLPAPERS) as WallpaperId[]).map((id) => {
              const w = WALLPAPERS[id];
              const selected = settings.wallpaper === id;
              return (
                <button
                  key={id}
                  className={cn(
                    "overflow-hidden rounded-2xl border text-left transition",
                    selected ? "ring-2 ring-[var(--desktop-accent)] border-transparent" : "hover:bg-white/10",
                  )}
                  onClick={() => onSettings({ ...settings, wallpaper: id })}
                  data-testid={`button-wallpaper-${id}`}
                >
                  <div className="aspect-[16/9] w-full">
                    <img src={w.src} alt={w.name} className="h-full w-full object-cover" data-testid={`img-wallpaper-${id}`} />
                  </div>
                  <div className="px-3 py-2">
                    <div className="text-[12px] font-medium">{w.name}</div>
                    <div className="text-[11px] text-muted-foreground">Click to apply</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

function AboutApp() {
  return (
    <div className="h-full p-4">
      <div className="text-sm font-semibold">About WebOS Desktop</div>
      <div className="mt-2 space-y-2 text-xs text-muted-foreground">
        <p data-testid="text-about-1">
          WebOS Desktop is a front-end demo that mimics a desktop operating system experience inside your browser.
        </p>
        <p data-testid="text-about-2">
          Notes are saved to <span className="font-medium">localStorage</span> on this device. Other apps use demo data.
        </p>
        <div className="rounded-xl border bg-white/50 dark:bg-white/5 p-3">
          <div className="text-xs font-medium">Publishing on Replit</div>
          <ol className="mt-1 list-decimal pl-5 space-y-1">
            <li>Click <span className="font-medium">Publish</span> in Replit.</li>
            <li>Choose a web deployment option.</li>
            <li>You’ll get a free link like <span className="font-medium">your-app.replit.app</span>.</li>
          </ol>
          <div className="mt-2 text-xs text-muted-foreground">
            Optional: If you later buy a custom domain, go to Deployments → Settings → Link a domain, then add the DNS
            records Replit shows you.
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Desktop() {
  const isMobile = useMemo(() => isSmallScreen(), []);

  const [firstRunDismissed, setFirstRunDismissed] = useLocalStorageState<boolean>(LS_KEYS.firstRun, false);
  const [notes, setNotes] = useLocalStorageState<string>(LS_KEYS.notes, "");

  const [settings, setSettings] = useLocalStorageState<SettingsState>(LS_KEYS.theme, {
    darkMode: true,
    accent: ACCENTS[0]!.value,
    wallpaper: "aurora",
  });

  const [windows, setWindows] = useState<WindowState[]>([]);
  const zTop = useRef(10);
  const draggingId = useRef<string | null>(null);
  const resizingId = useRef<string | null>(null);
  const dragOffset = useRef<{ dx: number; dy: number }>({ dx: 0, dy: 0 });
  const resizeStart = useRef<{ x: number; y: number; w: number; h: number }>({ x: 0, y: 0, w: 0, h: 0 });

  const [clock, setClock] = useState(() => formatClock(new Date()));
  const [date, setDate] = useState(() => formatDate(new Date()));
  const [startOpen, setStartOpen] = useState(false);

  useEffect(() => {
    const t = window.setInterval(() => {
      const now = new Date();
      setClock(formatClock(now));
      setDate(formatDate(now));
    }, 1000);
    return () => window.clearInterval(t);
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", settings.darkMode);
    document.documentElement.style.setProperty("--accent", settings.accent);
  }, [settings.darkMode, settings.accent]);

  const wallpaperSrc = WALLPAPERS[settings.wallpaper].src;

  function bringToFront(id: string) {
    zTop.current += 1;
    setWindows((prev) => prev.map((w) => (w.id === id ? { ...w, z: zTop.current } : w)));
  }

  function openApp(appId: AppId) {
    setStartOpen(false);
    zTop.current += 1;
    const idx = windows.length;
    const base = defaultWindowFor(appId, idx, isMobile);
    const win: WindowState = {
      ...base,
      z: zTop.current,
    };

    // On small screens, keep only one active window visually by minimizing others
    setWindows((prev) => {
      const next = isMobile ? prev.map((w) => ({ ...w, minimized: true })) : prev;
      return [...next, win];
    });
  }

  function closeWindow(id: string) {
    setWindows((prev) => prev.filter((w) => w.id !== id));
  }

  function toggleMinimize(id: string) {
    setWindows((prev) =>
      prev.map((w) => {
        if (w.id !== id) return w;
        const willMin = !w.minimized;
        if (!willMin) {
          zTop.current += 1;
          return { ...w, minimized: false, z: zTop.current };
        }
        return { ...w, minimized: true };
      }),
    );
  }

  function toggleMaximize(id: string) {
    setWindows((prev) =>
      prev.map((w) => {
        if (w.id !== id) return w;
        const nextMax = !w.maximized;
        return { ...w, maximized: nextMax, minimized: false };
      }),
    );
  }

  const activeWindowId = useMemo(() => {
    const visible = windows.filter((w) => !w.minimized);
    if (visible.length === 0) return null;
    return visible.reduce((a, b) => (a.z > b.z ? a : b)).id;
  }, [windows]);

  useEffect(() => {
    function onPointerMove(e: PointerEvent) {
      if (draggingId.current) {
        const id = draggingId.current;
        setWindows((prev) =>
          prev.map((w) => {
            if (w.id !== id) return w;
            if (w.maximized) return w;
            const nx = e.clientX - dragOffset.current.dx;
            const ny = e.clientY - dragOffset.current.dy;
            const maxX = window.innerWidth - 80;
            const maxY = window.innerHeight - 110;
            return { ...w, x: clamp(nx, 10, maxX), y: clamp(ny, 10, maxY) };
          }),
        );
      }

      if (resizingId.current) {
        const id = resizingId.current;
        setWindows((prev) =>
          prev.map((w) => {
            if (w.id !== id) return w;
            if (w.maximized || isMobile) return w;
            const dx = e.clientX - resizeStart.current.x;
            const dy = e.clientY - resizeStart.current.y;
            const nw = clamp(resizeStart.current.w + dx, 320, window.innerWidth - w.x - 12);
            const nh = clamp(resizeStart.current.h + dy, 220, window.innerHeight - w.y - 90);
            return { ...w, w: nw, h: nh };
          }),
        );
      }
    }

    function onPointerUp() {
      draggingId.current = null;
      resizingId.current = null;
    }

    window.addEventListener("pointermove", onPointerMove);
    window.addEventListener("pointerup", onPointerUp);
    return () => {
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerup", onPointerUp);
    };
  }, [isMobile]);

  function renderApp(appId: AppId) {
    switch (appId) {
      case "notes":
        return <NotesApp value={notes} onChange={setNotes} />;
      case "files":
        return <FilesApp />;
      case "browser":
        return <BrowserApp />;
      case "settings":
        return (
          <SettingsApp
            settings={settings}
            onSettings={setSettings}
            onOpenAbout={() => openApp("about")}
          />
        );
      case "about":
        return <AboutApp />;
    }
  }

  const desktopIcons = [
    { id: "notes" as const, label: "Notes", Icon: FileText },
    { id: "files" as const, label: "Files", Icon: Folder },
    { id: "browser" as const, label: "Browser", Icon: Globe },
    { id: "settings" as const, label: "Settings", Icon: Cog },
  ];

  return (
    <div
      className="relative h-full w-full overflow-hidden desktop-noise"
      onMouseDown={() => setStartOpen(false)}
      data-testid="page-desktop"
    >
      <div className="absolute inset-0">
        <img
          src={wallpaperSrc}
          alt="Wallpaper"
          className="h-full w-full object-cover"
          draggable={false}
          data-testid="img-wallpaper"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/25 via-black/15 to-black/45" />
      </div>

      <div className="relative z-10 flex h-full flex-col">
        <div className="flex-1 p-4 sm:p-6">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-1 sm:gap-3 w-fit">
            {desktopIcons.map((ic) => (
              <DesktopIcon
                key={ic.id}
                label={ic.label}
                Icon={ic.Icon}
                onOpen={() => openApp(ic.id)}
                testId={`icon-open-${ic.id}`}
              />
            ))}
          </div>

          <AnimatePresence>
            {windows
              .filter((w) => !w.minimized)
              .map((w) => {
                const meta = appMeta(w.appId);
                const active = w.id === activeWindowId;

                const style: React.CSSProperties = w.maximized
                  ? {
                      left: 10,
                      top: 10,
                      width: "calc(100% - 20px)",
                      height: "calc(100% - 90px)",
                      zIndex: w.z,
                    }
                  : {
                      left: w.x,
                      top: w.y,
                      width: w.w,
                      height: w.h,
                      zIndex: w.z,
                    };

                return (
                  <motion.div
                    key={w.id}
                    initial={{ opacity: 0, y: 10, scale: 0.99 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 8, scale: 0.99 }}
                    transition={{ duration: 0.16 }}
                    className={cn(
                      "absolute rounded-[18px] glass window-shadow overflow-hidden",
                      active ? "ring-2 ring-white/18" : "ring-1 ring-white/10",
                    )}
                    style={style}
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      bringToFront(w.id);
                    }}
                    data-testid={`window-${w.id}`}
                  >
                    <WindowChrome
                      title={w.title}
                      icon={meta.icon}
                      active={active}
                      maximized={w.maximized}
                      onMinimize={() => toggleMinimize(w.id)}
                      onMaximize={() => toggleMaximize(w.id)}
                      onClose={() => closeWindow(w.id)}
                      dragHandleProps={{
                        onPointerDown: (e: any) => {
                          if (isMobile) return;
                          bringToFront(w.id);
                          draggingId.current = w.id;
                          dragOffset.current = { dx: e.clientX - w.x, dy: e.clientY - w.y };
                          (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
                        },
                        style: { cursor: isMobile ? "default" : "grab" },
                      }}
                    />

                    <div className="h-[calc(100%-48px)] bg-white/35 dark:bg-black/20">
                      {renderApp(w.appId)}
                    </div>

                    {!isMobile && !w.maximized ? (
                      <ResizerHandle
                        onPointerDown={(e) => {
                          bringToFront(w.id);
                          resizingId.current = w.id;
                          resizeStart.current = { x: e.clientX, y: e.clientY, w: w.w, h: w.h };
                          (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
                        }}
                        testId={`handle-resize-${w.id}`}
                      />
                    ) : null}
                  </motion.div>
                );
              })}
          </AnimatePresence>
        </div>

        <div
          className={cn(
            "relative z-[9000] mx-3 mb-3 rounded-2xl glass taskbar-shadow",
            "px-2 py-2",
          )}
          data-testid="taskbar"
        >
          <div className="flex items-center gap-2">
            <button
              type="button"
              className={cn(
                "flex items-center gap-2 rounded-2xl px-3 py-2 text-[13px] font-medium",
                "bg-white/55 dark:bg-white/6 hover:bg-white/65 dark:hover:bg-white/9 transition",
              )}
              onClick={(e) => {
                e.stopPropagation();
                setStartOpen((v) => !v);
              }}
              data-testid="button-start"
            >
              <LayoutGrid className="h-4 w-4" />
              <span className="hidden sm:inline">Start</span>
            </button>

            <div className="flex-1 overflow-auto">
              <div className="flex items-center gap-2">
                {windows.map((w) => {
                  const meta = appMeta(w.appId);
                  const active = !w.minimized && w.id === activeWindowId;
                  const Icon = meta.icon;
                  return (
                    <button
                      key={w.id}
                      className={cn(
                        "flex items-center gap-2 rounded-2xl px-3 py-2 text-[12px] transition whitespace-nowrap",
                        active
                          ? "bg-[var(--desktop-accent)] text-white"
                          : "bg-white/45 dark:bg-white/5 hover:bg-white/60 dark:hover:bg-white/8",
                      )}
                      onClick={(e) => {
                        e.stopPropagation();
                        if (w.minimized) {
                          toggleMinimize(w.id);
                        } else if (active) {
                          toggleMinimize(w.id);
                        } else {
                          bringToFront(w.id);
                        }
                      }}
                      data-testid={`taskbar-window-${w.id}`}
                    >
                      <Icon className="h-4 w-4" />
                      <span className="max-w-[120px] truncate hidden sm:inline">{w.title}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                className="rounded-2xl px-3 py-2 text-right bg-white/45 dark:bg-white/5 hover:bg-white/60 dark:hover:bg-white/8 transition"
                onClick={(e) => {
                  e.stopPropagation();
                  openApp("settings");
                }}
                data-testid="button-open-settings"
              >
                <div className="text-[12px] font-medium" data-testid="text-taskbar-clock">
                  {clock}
                </div>
                <div className="text-[11px] text-muted-foreground" data-testid="text-taskbar-date">
                  {date}
                </div>
              </button>
            </div>
          </div>

          <StartMenu
            open={startOpen}
            onOpenApp={openApp}
            onClose={() => setStartOpen(false)}
            clock={clock}
            date={date}
            isMobile={isMobile}
          />
        </div>
      </div>

      {!firstRunDismissed ? (
        <FirstRunOverlay
          onDismiss={() => {
            setFirstRunDismissed(true);
          }}
        />
      ) : null}
    </div>
  );
}
